<?php get_header(); ?>
	<!-- 404-content -->
    <div class="notfound-content">
        <div class="notfound-container">
            <span>404</span>
            <h4>صفحه مورد نظر شما پیدا نشد.</h4>
            <em>صفحه ای که شما به دنبال آن هستید وجود ندارد!!</em>
            <a href="/">رفتن به صفحه اصلی</a>
        </div>
    </div>
	<!-- /404-content -->
<?php get_footer(); ?>
